package com.project.autos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectAutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
