package com.project.autos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectAutosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectAutosApplication.class, args);
	}

}
